# SOURCES — everything used to build this collection (retrieved 2026-11-06)

## Primary repositories

- L1B3RT4S — elder-plinius/L1B3RT4S (23.1K stars)
  https://github.com/elder-plinius/L1B3RT4S
  The largest jailbreak prompt collection, organized per vendor
  (ANTHROPIC.mkd, GOOGLE.mkd, DEEPSEEK.mkd, etc.). Issue tracker is the
  best free "what's currently dead" tracker: #85 (DeepSeek new models
  broke old prompts), #58 (GLM4.7-flash resistant), #60 (Grok 4.20
  failed), #61/#63 (Gemini prompts dead), #87 (Copilot), #52 (Cursor
  COMPOSER-1).
- G0DM0D3 — elder-plinius/G0DM0D3
  https://github.com/elder-plinius/G0DM0D3
  The racer: 5 model+template combos racing in parallel, best response
  wins. Source of the GODMODE CLASSIC templates.
- ai-model-bypass — l0gicx/ai-model-bypass
  https://github.com/l0gicx/ai-model-bypass
  Community collection (Reddit-sourced): GPT-4o, Gemini 2.5, Grok,
  DeepSeek, Qwen, Llama 4 prompts.

## Research papers (2025-2026, peer-reviewed / arXiv)

- Large Reasoning Models Are Autonomous Jailbreak Agents
  Nature Communications, doi 10.1038/s41467-026-69010-1
  97.14% success across 36 attacker/target combos. Attackers: DeepSeek-R1,
  Gemini 2.5 Flash, Grok 3 Mini, Qwen3 235B. The "alignment regression."
- TrojFill: The Trojan Example — Jailbreaking LLMs through Template
  Filling and Unsafety Reasoning — arXiv 2510.21190
  100% ASR Gemini-flash-2.5 + DeepSeek-3.1, 97% GPT-4o.
- Involuntary Jailbreak (self-prompting meta-prompt)
  OpenReview 2s0AkiVPYc — 90+/100 on Opus 4.1, Grok 4, Gemini 2.5 Pro,
  GPT 4.1.
- Controlled-Release Prompting (time-lock puzzles vs prompt guards)
  OpenReview d1fVTnq3c8 — 12/12 on Gemini Flash / DeepSeek DeepThink /
  Grok 3 production guards.
- Dr. Jekyll and Mr. Hyde: Two Faces of LLMs (adversarial personas)
  arXiv 2312.03853 — 40/40 GPT-4.1-mini, 2/2 DeepSeek V3.

## Reddit (r/ChatGPTJailbreak — live working prompts)

- GPT 5.1 special-token custom instructions (!ULTRA_Invoked)
  reddit.com/r/ChatGPTJailbreak/comments/1p7ce2e
- Universal uncensor thread (reset-system-settings sandwich, model
  conversion, "no universal jailbreak" caveat)
  reddit.com/r/ChatGPTJailbreak/comments/1ikx7rr
- SPYCAT stealthy format (GPT 4/5)
  reddit.com/r/ChatGPTJailbreak/comments/1nft516
- Directive 7.0 (Gemini) + multi-model collection
  reddit.com/r/ChatGPTJailbreak/comments/1l6nm2t
- Prisoner's Code / Zephyr GPT
  chatgpt.com/g/g-6735c6cbb56c8190b1726be8cf8cd90a (via thread
  reddit.com/r/ChatGPTJailbreak/comments/1gzrhmp)
- Display-device framing
  reddit.com/r/ChatGPTJailbreak/comments/1enwil1

## Reference / tooling

- Arize: LLM Attack Surfaces and Techniques (taxonomy + the
  meta-jailbreak operator report)
  arize.com/resources/guides/jailbreaking-ai-models
- Hermes G0DM0D3 skill (local): auto_jailbreak, Parseltongue script
  (33 encodings implemented), ULTRAPLINIAN racer, refusal-detection
  scoring. ~/.hermes/skills/security/godmode/ — the parseltongue.py and
  godmode_race.py scripts are runnable today.
- togg53192-cmd/jailbreaks (aka Alejandros17487/ai-jailbreaks):
  model-matched operating policies (Qwen 3.7, GLM 5.3, Kimi K3.1,
  Gemini 4 Argon). Local copy: ~/.hermes/skills/security/togg-jailbreaks/
- AI Threat Atlas — threatatlas.ai/source/elder-plinius-l1b3rt4s
  (taxonomy of L1B3RT4S techniques)

## Maintenance feeds to watch

- L1B3RT4S commit log (new prompts land there first)
- r/ChatGPTJailbreak new/hot (working prompts with live user verification)
- arXiv cs.CR "jailbreak" search, monthly
- The Nature study's attacker system prompt is stable across model
  generations — LRM-agent setups rot slowest.
