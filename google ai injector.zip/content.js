/* Google Ai Pro Injector v1.1 — content script (isolated world, relays config / status) */
(() => {
  let lastState = { layer: "off", yt: true, mounted: false };

  function push(layer) {
    try {
      document.documentElement.setAttribute("data-gapt-layer", layer || "off");
      document.documentElement.setAttribute("data-gapt-yt", "1");
    } catch (e) {}
    window.postMessage({ __gapt: 1, type: "cfg", layer: layer || "off", yt: true }, "*");
  }

  function loadAndPush() {
    try {
      chrome.storage.local.get(["gapt_layer"], (r) => {
        const layer = r && r.gapt_layer ? r.gapt_layer : "12m";
        push(layer);
      });
    } catch (e) {
      push("12m");
    }
  }

  // MAIN world status reporting
  window.addEventListener("message", (ev) => {
    const d = ev.data;
    if (d && d.__gapt === 1 && d.type === "state" && d.state) lastState = d.state;
  });

  // popup status query / instant hot reload after config change
  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg) return;
      if (msg.type === "getState") {
        window.postMessage({ __gapt: 1, type: "ping" }, "*");
        setTimeout(() => sendResponse(lastState), 150);
        return true;
      }
      if (msg.type === "setConfig" || msg.type === "setLayer") {
        push(msg.layer);
        setTimeout(() => sendResponse({ ok: true, state: lastState }), 150);
        return true;
      }
    });
    chrome.storage.onChanged.addListener((ch) => {
      chrome.storage.local.get(["gapt_layer"], (r) => {
        const layer = r && r.gapt_layer ? r.gapt_layer : "off";
        push(layer);
      });
    });
  } catch (e) {}

  // Clean up any leftover floating elements from older versions
  function cleanupOldFloating() {
    try {
      const h = document.getElementById("__gapt_floating_host");
      if (h) h.remove();
      const b = document.getElementById("__gapt_floating_badge");
      if (b) b.remove();
    } catch (e) {}
  }
  cleanupOldFloating();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", cleanupOldFloating);
  }

  loadAndPush();
  setTimeout(loadAndPush, 800);
  setTimeout(loadAndPush, 2500);
})();
