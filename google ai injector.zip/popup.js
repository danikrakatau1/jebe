/* popup.js — Google AI Pro Studio Controller */
const LABELS = {
  off: "Disabled / Standby",
  "12m": "Layer 1 · 12 Months",
  "6m_ss": "Layer 2 · +6 Months (SS)",
  "6m": "Layer 3 · +6 Months (Std)",
  "6m_2": "Backup · 6 Months (Alt)"
};

const masterStatus = document.getElementById("master-status");
const masterStatusText = document.getElementById("master-status-text");
const hudMainStatus = document.getElementById("hud-main-status");
const hudSubStatus = document.getElementById("hud-sub-status");
const copyZipBtn = document.getElementById("copy-zip-btn");

function updateTierCards(selectedVal) {
  document.querySelectorAll(".tier-card").forEach((card) => {
    const radio = card.querySelector('input[type="radio"]');
    if (radio) {
      const isSelected = radio.value === selectedVal;
      radio.checked = isSelected;
      card.classList.toggle("selected", isSelected);
    }
  });
}

function paintState(st) {
  const layer = (st && st.layer) || "off";
  const mounted = !!(st && st.mounted) && layer !== "off";

  if (masterStatus && masterStatusText) {
    masterStatus.className = mounted ? "status-badge ok" : "status-badge warn";
    masterStatusText.textContent = mounted ? "ACTIVE" : "STANDBY";
  }

  if (hudMainStatus && hudSubStatus) {
    if (mounted) {
      hudMainStatus.innerHTML = '<span style="color:#4ade80;">● Mounted:</span> ' + (LABELS[layer] || layer);
      const hints = {
        "12m": "Step 1: Klik 'Dapatkan diskon' di Google One & subscribe ($0.00).",
        "6m_ss": "Step 2: Masuk lagi ke Google One & klik tombol 'Upgrade' &rarr; Jadi 18 Bulan! (Harga web bukan $0 cuma bug visual).",
        "6m": "Step 3: Klik tombol 'Upgrade' lagi di Google One &rarr; Genap 24 Bulan!",
        "6m_2": "Backup: Klik tombol 'Upgrade' & subscribe ($0.00)."
      };
      hudSubStatus.innerHTML = hints[layer] || "Ready! Buka Google One & subscribe.";
    } else {
      hudMainStatus.innerHTML = '<span style="color:#f59e0b;">○ Standby:</span> Target not connected';
      hudSubStatus.textContent = "Open one.google.com/plans & refresh page.";
    }
  }
}

function sendConfigToActiveTab(layer) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const t = tabs && tabs[0];
    if (!t) return queryTab();
    chrome.tabs.sendMessage(t.id, { type: "setConfig", layer: layer, yt: true }, () => {
      void chrome.runtime.lastError;
      setTimeout(queryTab, 300);
    });
  });
}

function queryTab() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const t = tabs && tabs[0];
    if (!t) return paintState(null);
    chrome.tabs.sendMessage(t.id, { type: "getState" }, (resp) => {
      if (chrome.runtime.lastError || !resp) return paintState(null);
      paintState(resp);
    });
  });
}

// Initialize Storage & UI
chrome.storage.local.get(["gapt_layer"], (r) => {
  const layer = (r && r.gapt_layer) || "12m";
  updateTierCards(layer);

  // Setup Tier Card Selection
  document.querySelectorAll(".tier-card").forEach((card) => {
    card.addEventListener("click", () => {
      const radio = card.querySelector('input[type="radio"]');
      if (!radio) return;
      const selectedLayer = radio.value;
      updateTierCards(selectedLayer);
      chrome.storage.local.set({ gapt_layer: selectedLayer }, () => {
        sendConfigToActiveTab(selectedLayer);
      });
    });
  });

  // Quick Copy US ZIP
  if (copyZipBtn) {
    copyZipBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      navigator.clipboard.writeText("97201").then(() => {
        copyZipBtn.classList.add("copied");
        const originalHtml = copyZipBtn.innerHTML;
        copyZipBtn.innerHTML = '<span>✓ Copied 97201</span>';
        setTimeout(() => {
          copyZipBtn.classList.remove("copied");
          copyZipBtn.innerHTML = originalHtml;
        }, 1500);
      }).catch(() => {});
    });
  }

  // Open Google One Plans (Fitur #2)
  const openPlansBtn = document.getElementById("open-plans-btn");
  if (openPlansBtn) {
    openPlansBtn.addEventListener("click", () => {
      chrome.tabs.create({ url: "https://one.google.com/plans" });
    });
  }

  // Open Google Play Subscriptions - Cancel Auto-Renew (Fitur #3)
  const openPlaySubsBtn = document.getElementById("open-play-subs-btn");
  if (openPlaySubsBtn) {
    openPlaySubsBtn.addEventListener("click", () => {
      chrome.tabs.create({ url: "https://play.google.com/store/account/subscriptions" });
    });
  }

  // Troubleshooting Collapsible Drawer (Fitur #5)
  const tsToggle = document.getElementById("troubleshoot-toggle");
  const tsContent = document.getElementById("troubleshoot-content");
  if (tsToggle && tsContent) {
    tsToggle.addEventListener("click", () => {
      const isExpanded = tsContent.classList.toggle("open");
      tsToggle.classList.toggle("active", isExpanded);
    });
  }

  queryTab();
  setTimeout(queryTab, 600);
});

setInterval(queryTab, 1500);
