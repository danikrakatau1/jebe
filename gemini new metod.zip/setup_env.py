"""setup_env.py —— Menyiapkan lingkungan eksekusi sekali klik (Python + frida + adb + koneksi emulator)

Melakukan 4 tahapan:
  1. Memeriksa versi Python
  2. Memasang frida 16.5.9 (diperlukan untuk injeksi script; 17.x menghapus Java bridge)
  3. Mencari adb: environment variables → PATH → MuMu bawaan → jika tidak ada otomatis download platform-tools
  4. Menghubungkan emulator lalu menjalankan uji mandiri dengan ultra0.py --check

Cara pakai: klik ganda Cai_dat_moi_truong.bat, atau jalankan python setup_env.py
"""
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
ADB_CANDIDATES = [
    os.environ.get("ADB_PATH", ""),
    r"C:\Program Files\Netease\MuMuPlayer-12.0\shell\adb.exe",
    r"C:\Program Files\Netease\MuMuPlayerGlobal-12.0\shell\adb.exe",
    r"C:\Program Files (x86)\Netease\MuMuPlayer-12.0\shell\adb.exe",
    r"D:\Program Files\Netease\MuMu\nx_main\adb.exe",
    r"D:\Program Files\Netease\MuMu\nx_device\12.0\shell\adb.exe",
    r"C:\Program Files\Netease\MuMu\nx_main\adb.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"),
    os.path.expandvars(r"%USERPROFILE%\AppData\Local\Android\Sdk\platform-tools\adb.exe"),
]
PLATFORM_TOOLS_URL = "https://dl.google.com/android/repository/platform-tools-latest-windows.zip"


def step(msg):
    print(f"\n▶ {msg}", flush=True)


def ok(msg):
    print(f"   ✅ {msg}", flush=True)


def warn(msg):
    print(f"   ⚠️  {msg}", flush=True)


def die(msg):
    print(f"\n❌ {msg}", flush=True)
    sys.exit(1)


def check_python():
    step("Memeriksa Python")
    v = sys.version_info
    print(f"   {platform.python_version()}  ({platform.architecture()[0]})")
    if v < (3, 9):
        die("Versi Python terlalu rendah, silakan pasang Python 3.10 ke atas: https://www.python.org/downloads/")
    ok("Python siap digunakan")


def install_frida():
    step("Memasang frida 16.5.9 (diperlukan untuk injeksi)")
    try:
        import frida
        if frida.__version__.startswith("16."):
            ok(f"Frida {frida.__version__} sudah terpasang")
            return
        warn(f"Terdeteksi frida {frida.__version__}, versi 17.x tidak kompatibel, sedang menurunkan versi…")
    except Exception:
        pass

    cmds = [
        [sys.executable, "-m", "pip", "install", "--no-cache-dir", "frida==16.5.9"],
        [sys.executable, "-m", "pip", "install", "--no-cache-dir",
         "-i", "https://pypi.tuna.tsinghua.edu.cn/simple", "frida==16.5.9"],
    ]
    for c in cmds:
        print("   " + " ".join(c[2:]))
        r = subprocess.run(c, capture_output=True, text=True, errors="ignore")
        if r.returncode == 0:
            break
        print("   " + (r.stderr or r.stdout).strip().splitlines()[-1][:160])
    try:
        import importlib
        import frida
        importlib.reload(frida)
        ok(f"Selesai memasang frida {frida.__version__}")
    except Exception as e:
        die(f"Gagal memasang frida: {e}\n   Pasang manual: pip install frida==16.5.9")


def download_platform_tools():
    dest = BASE / "platform-tools"
    print(f"   Mengunduh platform-tools ke {dest}")
    tmp = Path(tempfile.gettempdir()) / "platform-tools.zip"
    with urllib.request.urlopen(PLATFORM_TOOLS_URL, timeout=180) as r, open(tmp, "wb") as f:
        f.write(r.read())
    with zipfile.ZipFile(tmp) as z:
        z.extractall(BASE)
    tmp.unlink(missing_ok=True)
    adb = dest / "adb.exe"
    if adb.exists():
        ok(f"platform-tools siap digunakan: {adb}")
        return str(adb)
    die("Selesai mengekstrak platform-tools tetapi adb.exe tidak ditemukan")


def find_adb():
    step("Mencari adb")
    for c in ADB_CANDIDATES:
        if not c:
            continue
        if c in ("adb", "adb.exe"):
            continue
        if Path(c).exists():
            ok(f"Menggunakan {c}")
            return c
    w = shutil.which("adb")
    if w:
        ok(f"Menggunakan {w} di PATH")
        return w
    warn("adb tidak ditemukan, mulai mengunduh otomatis")
    return download_platform_tools()


def connect_emulator(adb):
    step("Menghubungkan ke emulator")
    ports = ["16384", "7555", "16416", "21503", "62001"]
    for p in ports:
        subprocess.run([adb, "connect", f"127.0.0.1:{p}"], capture_output=True, text=True, errors="ignore")
    out = subprocess.run([adb, "devices"], capture_output=True, text=True, errors="ignore").stdout
    devices = [l.split("\t")[0] for l in out.splitlines()[1:] if "\tdevice" in l]
    if not devices:
        warn("Belum ada perangkat yang terhubung. Pastikan MuMu sudah berjalan dan USB Debugging ADB telah diaktifkan di Pengaturan")
        print("   " + out.strip().replace("\n", "\n   "))
        return None
    ok(f"Perangkat terhubung: {', '.join(devices)}")
    return devices[0]


def run_check(adb, serial):
    step("Menjalankan uji mandiri lingkungan (ultra0.py --check)")
    env = dict(os.environ)
    env["ADB_PATH"] = adb
    env["PYTHONIOENCODING"] = "utf-8"
    r = subprocess.run([sys.executable, "ultra0.py", "--check"], cwd=str(BASE),
                       env=env, capture_output=True, encoding="utf-8", errors="ignore")
    print(r.stdout.strip() or r.stderr.strip())
    return r.returncode == 0


def main():
    print("=" * 60)
    print("  Google Ultra / Pro Aktivasi Satu Klik · Pengaturan Lingkungan")
    print("=" * 60)
    check_python()
    install_frida()
    adb = find_adb()
    serial = connect_emulator(adb)

    if serial:
        good = run_check(adb, serial)
        print("\n" + "=" * 60)
        if good:
            print("  ✅ Lingkungan telah siap! Klik ganda «2_Pro_12_thang_Buoc_1.bat» untuk mulai aktivasi")
        else:
            print("  ⚠️  Uji mandiri belum lengkap, lihat petunjuk di atas (biasanya karena Google Play Store belum dibuka)")
        print("=" * 60)
    else:
        print("\nSilakan buka MuMu dan aktifkan ADB debugging, lalu jalankan script ini kembali.")


if __name__ == "__main__":
    main()
