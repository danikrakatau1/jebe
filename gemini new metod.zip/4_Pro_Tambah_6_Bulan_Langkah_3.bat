@echo off
chcp 65001 >nul
title Pro +6 Bulan - Langkah 3 (Total 24 Bulan / 2 Tahun)
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo ============================================
echo   Google AI Pro 2TB/5TB - Tambah 6 Bulan (Langkah 3)
echo   HANYA dijalankan setelah Langkah 2 BERHASIL!
echo   Total masa aktif akan menjadi 24 Bulan (2 Tahun Gratis).
echo ============================================
python ultra0.py --account "current@device" --no-add --force --stack --plan pro6b
echo.
pause
