@echo off
chcp 65001 >nul
title Lihat Daftar Penawaran (Offer)
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo ============================================
echo   Melihat Daftar Offer Gratis Akun Google Saat Ini
echo   (Hanya menampilkan info, tidak melakukan pembelian, 100%% aman)
echo ============================================
python ultra0.py --list
echo.
pause
