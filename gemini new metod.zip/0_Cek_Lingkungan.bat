@echo off
chcp 65001 >nul
title Cek Lingkungan
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo ============================================
echo   Memeriksa Emulator / Frida / Modul Billing
echo ============================================
python ultra0.py --check
echo.
pause
