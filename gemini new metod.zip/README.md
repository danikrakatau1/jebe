# Panduan Lengkap Aktivasi Google AI Pro 2 Tahun Gratis ($0.00)
> **Untuk Pemula & Orang Awam** — Panduan langkah demi langkah dari nol (tanpa pengalaman coding sama sekali).

Tools ini berfungsi untuk mengaktifkan paket langganan **Google AI Pro (2TB / 5TB Cloud Storage + Google Gemini Pro / Advanced)** dengan durasi total hingga **24 Bulan (2 Tahun Penuh)** secara resmi dan gratis ($0.00) melalui integrasi Google Play Billing di emulator Android.

---

## 📑 Daftar Isi
1. [Syarat & Bahan yang Diperlukan](#1-syarat--bahan-yang-diperlukan)
2. [Langkah 1: Download & Install Python (Jika Belum Ada)](#langkah-1-download--install-python-jika-belum-ada)
3. [Langkah 2: Download & Pengaturan Emulator MuMu Player 12](#langkah-2-download--pengaturan-emulator-mumu-player-12)
4. [Langkah 3: Pengaturan Akun Google & Profil Pembayaran](#langkah-3-pengaturan-akun-google--profil-pembayaran)
5. [Langkah 4: Menjalankan Skrip Aktivasi (Tinggal Klik-Klik)](#langkah-4-menjalankan-skrip-aktivasi-tinggal-klik-klik)
6. [Langkah 5: Memeriksa Hasil Aktivasi 2 Tahun](#langkah-5-memeriksa-hasil-aktivasi-2-tahun)
7. [Tanya Jawab & Solusi Kendala (Troubleshooting)](#tanya-jawab--solusi-kendala-troubleshooting)

---

## 1. Syarat & Bahan yang Diperlukan
- Komputer / Laptop dengan sistem operasi **Windows 10 atau Windows 11**.
- Koneksi internet stabil.
- Akun Google (bisa akun baru atau akun utama yang saat ini belum memiliki langganan Google One aktif).
- Kartu debit/kredit/virtual card (misalnya Bank Jago, Jenius, BCA, Mandiri, Blu, SeaBank, dsb.) dengan saldo minimal Rp 16.000 ($1) untuk verifikasi awal Google Play (akan langsung di-refund $0.00).

---

## Langkah 1: Download & Install Python (Jika Belum Ada)

Jika di komputer kamu belum pernah terpasang Python, ikuti langkah berikut:

1. Buka browser dan buka situs resmi Python:  
   👉 **[https://www.python.org/downloads/](https://www.python.org/downloads/)**
2. Klik tombol kuning besar bertuliskan **"Download Python 3.12.x"** (atau versi 3.10 ke atas).
3. Buka file installer `.exe` yang baru saja kamu download.
4. ⚠️ **BAGIAN PALING PENTING (JANGAN SAMPAI TERLEWAT):**  
   Di jendela instalasi paling awal bagian bawah, **WAJIB CENTANG** kotak:
   - ☑️ **"Add python.exe to PATH"** *(atau "Add Python to environment variables")*.
   *(Jika opsi ini tidak dicentang, file `.bat` tidak akan bisa mendeteksi perintah Python).*
5. Setelah dicentang, klik **"Install Now"** di bagian atas.
6. Tunggu proses instalasi selesai sampai muncul tulisan **"Setup was successful"**, lalu klik **Close**.

> 💡 **Cara Memastikan Python Sudah Terpasang:**  
> Tekan tombol `Windows + R` di keyboard, ketik `cmd` lalu tekan `Enter`.  
> Di layar hitam ketik: `python --version` lalu tekan `Enter`.  
> Jika muncul teks seperti `Python 3.12.x`, artinya Python sudah berhasil terpasang sempurna!

---

## Langkah 2: Download & Pengaturan Emulator MuMu Player 12

Skrip ini memerlukan emulator Android yang memiliki akses Root untuk mengaitkan promo resmi ke Play Store.

1. Buka situs resmi MuMu Player:  
   👉 **[https://www.mumuplayer.com/](https://www.mumuplayer.com/)**
2. Download dan install **MuMu Player 12**.
3. Buka aplikasi MuMu Player yang sudah terpasang.
4. **Aktifkan Izin Root & ADB (Wajib):**
   - Klik ikon **Gerigi (Pengaturan/Settings)** di pojok kanan atas jendela MuMu.
   - Pilih menu **Umum (Basic)**: Pada bagian **Izin Root (Root Permission)**, ubah menjadi **Aktif (Enable)**.
   - Pilih menu **Pengaturan Lainnya / Lanjutan**: Pastikan opsi **ADB Debugging / USB Debugging** dalam kondisi **Aktif / Buka**.
   - Klik **Simpan Perubahan (Save Changes)** dan biarkan MuMu merestart.

---

## Langkah 3: Pengaturan Akun Google & Profil Pembayaran

1. **Login Akun Google di MuMu:**
   - Di dalam emulator MuMu, buka aplikasi **Google Play Store**.
   - Login menggunakan akun Google yang ingin kamu berikan langganan 2 tahun.
2. **Pasang Alamat US Oregon (Bebas Pajak):**
   - Buka browser di PC kamu dan masuk ke: **[https://payments.google.com/](https://payments.google.com/)**
   - Masuk ke tab **Setelan (Settings)** > **Profil Pembayaran (Payment Profile)**.
   - Pastikan negara diatur ke **United States (US)** dengan alamat bebas pajak Oregon berikut:
     - **Baris Alamat 1:** `700 Southwest 5th Avenue`
     - **Kota:** `Portland`
     - **Negara Bagian (State):** `Oregon (OR)`
     - **Kodepos (ZIP):** `97201`
3. **Tambahkan Metode Pembayaran:**
   - Di Google Play Store (atau di payments.google.com), tambahkan kartu debit/kredit kamu.
   - Pastikan kartu kamu memiliki saldo minimal sekitar Rp 16.000 ($1) untuk otorisasi uji coba Google (langsung dikembalikan saat itu juga).
4. **Install Google One di Emulator:**
   - Buka Google Play Store di dalam MuMu.
   - Cari aplikasi **Google One**, lalu klik **Install**.

---

## Langkah 4: Menjalankan Skrip Aktivasi (Tinggal Klik-Klik)

Masuk ke folder `AI 2028 NEW` di komputer kamu. Jalankan file-file batch berikut sesuai urutan nomornya:

### 1️⃣ Jalankan: `Pengaturan_Lingkungan.bat`
- Klik ganda (double-click) file **`Pengaturan_Lingkungan.bat`**.
- Skrip akan otomatis mengunduh komponen Frida versi yang tepat dan menyambungkan PC ke emulator MuMu.
- Tekan `Enter` jika diminta.

### 2️⃣ Jalankan: `0_Cek_Lingkungan.bat`
- Klik ganda file **`0_Cek_Lingkungan.bat`**.
- Skrip akan mengecek apakah MuMu, modul billing, dan Play Store sudah terhubung.
- Jika semua baris menampilkan centang hijau `✅`, artinya siap lanjut ke langkah berikutnya!

### 3️⃣ Jalankan: `2_Pro_12_Bulan_Langkah_1.bat` (Aktivasi 12 Bulan Pertama)
- Klik ganda file **`2_Pro_12_Bulan_Langkah_1.bat`**.
- Lihat layar emulator MuMu kamu: Aplikasi Google One akan terbuka dan menampilkan jendela pop-up Google Play Store.
- ⚠️ **PERIKSA DENGAN TELITI:**  
  Pastikan di jendela pop-up Google Play tertulis **"Uji coba gratis 12 bulan"** atau harga tertera **"$0.00"** / **"Rp 0"**.
- Klik tombol **"Langganan" / "Subscribe"**.
- Selamat, kamu sudah mendapatkan 12 bulan pertama!

### 4️⃣ Jalankan: `3_Pro_Tambah_6_Bulan_Langkah_2.bat` (Tambah 6 Bulan -> Total 18 Bulan)
- Setelah langkah 1 selesai, klik ganda file **`3_Pro_Tambah_6_Bulan_Langkah_2.bat`**.
- Di layar MuMu, pop-up Google Play akan muncul kembali untuk upgrade penumpukan (*stacking*).
- Konfirmasi nominal $0.00, lalu klik **"Langganan" / "Subscribe"**.
- Masa aktif kamu sekarang menjadi **18 Bulan**.

### 5️⃣ Jalankan: `4_Pro_Tambah_6_Bulan_Langkah_3.bat` (Tambah 6 Bulan Lagi -> Total 24 Bulan / 2 Tahun)
- Klik ganda file **`4_Pro_Tambah_6_Bulan_Langkah_3.bat`**.
- Di layar MuMu, konfirmasi langganan $0.00 sekali lagi.
- Selesai! Masa aktif Google AI Pro kamu sekarang resmi menjadi **24 Bulan (2 Tahun Penuh Gratis)**.

> 💡 *Opsional:* Terdapat file `5_Pro_Cadangan_6_Bulan.bat` jika ingin menambah cadangan 6 bulan lagi (maksimal hingga 30 bulan).

---

## Langkah 5: Memeriksa Hasil Aktivasi 2 Tahun

Untuk memastikan masa aktif 2 tahun sudah benar-benar masuk ke akun kamu:

1. Buka browser di komputer atau HP kamu.
2. Kunjungi halaman kelola langganan resmi Google:  
   👉 **[https://play.google.com/store/account/subscriptions](https://play.google.com/store/account/subscriptions)**
3. Klik langganan **Google One**.
4. Periksa **Tanggal Penagihan Berikutnya (Next Payment)**:
   - Tanggal harus menunjukkan 2 tahun ke depan (misalnya: *19 November 2028*).
   - Di bawahnya tertera tagihan hari ini: **$0.00**.

Begitu langganan aktif, manfaatnya (penyimpanan cloud Drive/Photos 2TB/5TB dan akses Gemini Pro/Advanced) bisa langsung kamu nikmati di semua perangkat (laptop, iPhone, HP Android, dll.) hanya dengan login akun Google tersebut. Kamu tidak perlu membuka emulator MuMu lagi!

---

## Tanya Jawab & Solusi Kendala (Troubleshooting)

#### ❓ Muncul pesan: `'python' is not recognized as an internal or external command`
- **Penyebab:** Python belum terpasang atau saat instalasi kamu lupa mencentang "Add python.exe to PATH".
- **Solusi:** Buka kembali file installer Python, pilih *Modify* atau install ulang, dan pastikan centang opsi **"Add python.exe to PATH"**.

#### ❓ Muncul pesan: `The item you requested is not available for purchase` di Play Store
- **Penyebab:** Akun Google belum memiliki metode pembayaran aktif, atau profil negara masih Indonesia.
- **Solusi:** Tambahkan kartu debit/kredit di payments.google.com dengan alamat US Oregon (ZIP: 97201), lalu buka Google Play Store di MuMu sekali lagi.

#### ❓ Muncul pesan: `Chưa kết nối được thiết bị nào` / Belum ada perangkat terhubung
- **Penyebab:** Emulator MuMu belum terbuka atau fitur USB Debugging belum aktif.
- **Solusi:** Buka MuMu Player terlebih dahulu, pastikan izin Root aktif di pengaturan MuMu, lalu jalankan kembali skripnya.

#### ❓ Kapan waktu yang aman untuk membatalkan perpanjangan otomatis?
- **Penting:** **JANGAN** membatalkan langganan sebelum kamu menyelesaikan Langkah 1, Langkah 2, dan Langkah 3. Jika dibatalkan di tengah jalan, fitur penumpukan 6 bulan berikutnya akan gagal.
- Setelah langkah 3 selesai dan tanggal sudah maju 2 tahun, kamu bebas membatalkan perpanjangan otomatis kapan saja agar tidak tertagih setelah 2 tahun habis. Hak akses 2 tahun gratis kamu tetap aktif sampai tanggal berakhir.
