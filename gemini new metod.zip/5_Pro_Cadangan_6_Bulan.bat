@echo off
chcp 65001 >nul
title Pro Cadangan +6 Bulan (Opsional)
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo ============================================
echo   Google AI Pro 2TB/5TB - Cadangan Tambahan 6 Bulan
echo   Gunakan hanya jika ketiga langkah sebelumnya sudah berhasil (maks 30 bulan).
echo ============================================
python ultra0.py --account "current@device" --no-add --force --stack --plan pro6c
echo.
pause
