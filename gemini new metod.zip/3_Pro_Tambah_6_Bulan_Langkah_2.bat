@echo off
chcp 65001 >nul
title Pro +6 Bulan - Langkah 2 (Total 18 Bulan)
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo ============================================
echo   Google AI Pro 2TB/5TB - Tambah 6 Bulan (Langkah 2)
echo   HANYA dijalankan setelah Langkah 1 BERHASIL!
echo   Sistem akan menumpuk (stack) durasi uji coba lama + 6 bulan baru.
echo ============================================
python ultra0.py --account "current@device" --no-add --force --stack --plan pro6
echo.
pause
