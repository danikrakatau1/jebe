@echo off
chcp 65001 >nul
title Pro 12 Bulan - Langkah 1
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
echo ============================================
echo   Google AI Pro 2TB/5TB - Gratis 12 Bulan (Langkah 1)
echo   Pastikan jendela pembayaran Google Play bertuliskan:
echo   "Uji coba gratis 12 bulan" atau "$0.00"
echo   JANGAN klik konfirmasi jika tertulis berbayar atau hanya 1 bulan!
echo ============================================
python ultra0.py --account "current@device" --no-add --force --plan pro12
echo.
pause
