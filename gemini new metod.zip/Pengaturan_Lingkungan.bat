@echo off
chcp 65001 >nul
title Pengaturan Lingkungan Otomatis
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8

echo ============================================================
echo   Google Ultra / Pro - Instalasi & Cek Lingkungan Otomatis
echo   - Periksa Python
echo   - Pasang Frida 16.5.9
echo   - Cari atau unduh adb
echo   - Hubungkan ke MuMu dan uji mandiri
echo ============================================================
echo.
pause

python setup_env.py

echo.
echo ------------------------------------------------------------
echo   Selesai. Jika semua centang hijau, buka 2_Pro_12_Bulan_Langkah_1.bat
echo ------------------------------------------------------------
pause
