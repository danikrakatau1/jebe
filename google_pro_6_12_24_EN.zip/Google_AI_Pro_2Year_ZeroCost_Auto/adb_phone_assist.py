"""ADB phone assist — pass Google device/phone verification walls using a USB-connected
Android phone. Flow: decode the QR shown on the PC page, open its verification URL on the
phone (equivalent to scanning it with the camera), then tap the confirm button via
uiautomator. The phone must be signed into the target Google account for the confirm
step to be accepted."""

import os
import re
import shutil
import subprocess
import time
from typing import List, Optional

ADB_CANDIDATES = [
    shutil.which("adb"),
    os.path.expandvars(r"%LOCALAPPDATA%\Android\Sdk\platform-tools\adb.exe"),
    r"C:\Program Files (x86)\Android\android-sdk\platform-tools\adb.exe",
    r"C:\Android\platform-tools\adb.exe",
    r"C:\adb\platform-tools\adb.exe",
]


def find_adb() -> Optional[str]:
    for cand in ADB_CANDIDATES:
        if cand and os.path.exists(cand):
            return cand
    return None


def _run(adb_path: str, device: Optional[str], *args, timeout: int = 15):
    cmd = [adb_path]
    if device:
        cmd += ["-s", device]
    cmd += list(args)
    proc = subprocess.run(cmd, capture_output=True, timeout=timeout)
    return proc.stdout.decode("utf-8", errors="ignore"), proc.returncode


def list_devices(adb_path: str) -> List[str]:
    """Return serials of devices in 'device' (authorized) state."""
    out, _ = _run(adb_path, None, "devices")
    serials = []
    for line in out.splitlines()[1:]:
        parts = line.strip().split()
        if len(parts) >= 2 and parts[1] == "device":
            serials.append(parts[0])
    return serials


def wake_unlock(adb_path: str, device: str) -> None:
    _run(adb_path, device, "shell", "input", "keyevent", "KEYCODE_WAKEUP")
    _run(adb_path, device, "shell", "wm", "dismiss-keyguard")
    # small upward swipe in case a lock-screen swipe layer is still up
    _run(adb_path, device, "shell", "input", "swipe", "540", "1600", "540", "600", "120")


def open_url(adb_path: str, device: str, url: str) -> None:
    _run(adb_path, device, "shell", "am", "start", "-a", "android.intent.action.VIEW", "-d", url)


def dump_ui(adb_path: str, device: str) -> str:
    """Capture the current UI hierarchy as XML (works even when the browser is on top)."""
    out, _ = _run(adb_path, device, "exec-out", "uiautomator", "dump", "/dev/tty", timeout=18)
    if "<hierarchy" not in out:
        # older devices cannot dump to /dev/tty — use the file route
        _run(adb_path, device, "shell", "uiautomator", "dump", "/sdcard/ui_dump.xml", timeout=18)
        out, _ = _run(adb_path, device, "shell", "cat", "/sdcard/ui_dump.xml", timeout=12)
    return out


def _parse_nodes(xml: str):
    nodes = []
    for tag in re.findall(r"<node[^>]*>", xml):
        m_text = re.search(r'\stext="([^"]*)"', tag)
        m_desc = re.search(r'\scontent-desc="([^"]*)"', tag)
        m_bounds = re.search(r'\sbounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"', tag)
        if not m_bounds:
            continue
        x1, y1, x2, y2 = map(int, m_bounds.groups())
        nodes.append(
            {
                "text": (m_text.group(1) if m_text else "").strip(),
                "desc": (m_desc.group(1) if m_desc else "").strip(),
                "cx": (x1 + x2) // 2,
                "cy": (y1 + y2) // 2,
                "clickable": 'clickable="true"' in tag,
            }
        )
    return nodes


# Exact-match labels — tapped ONLY on full-text equality (headings never match these).
CONFIRM_EXACT = [
    "yes",
    "ya",
    "allow",
    "izinkan",
    "lanjutkan",
    "continue",
    "setuju",
    "i agree",
    "saya setuju",
    "masuk",
    "sign in",
    "verify",
    "verifikasi",
    "confirm",
    "konfirmasi",
    "ok",
    "oke",
    "got it",
    "mulai",
    "start",
    "berikutnya",
    "next",
    "coba lagi",
    "try again",
]
# Prefix-match labels — tapped ONLY when the node is actually clickable, so long
# headings like "Verifikasi nomor telepon Anda" can never be mistaken for buttons.
CONFIRM_PREFIX = [
    "yes",
    "ya",
    "allow",
    "izinkan",
    "lanjutkan",
    "continue",
    "setuju",
    "i agree",
    "saya setuju",
    "masuk",
    "sign in",
    "kirim",
    "send",
    "mulai",
    "start",
    "berikutnya",
    "next",
]

# Markers of a Google error/retry page on the phone (the verification attempt itself failed).
ERROR_MARKERS = ["coba lagi", "try again", "terjadi error", "an error occurred", "couldn't verify", "tidak dapat memverifikasi"]


def detect_error_state(adb_path: str, device: str) -> Optional[str]:
    """Return the offending label if the phone currently shows an error/retry page."""
    xml = dump_ui(adb_path, device)
    for n in _parse_nodes(xml):
        label = (n["text"] or n["desc"]).strip().lower()
        for marker in ERROR_MARKERS:
            if marker in label:
                return (n["text"] or n["desc"]).strip()
    return None


def tap_button_by_text(adb_path: str, device: str, timeout: int = 25, extra_labels=None) -> Optional[str]:
    """Poll the phone UI until a confirm-looking button appears, then tap it.
    extra_labels (e.g. the account email) are matched exactly and take priority —
    they cover the Google account picker when several accounts live on the phone.
    Returns the matched label, or None if nothing matched within the timeout."""
    extra = [x.lower() for x in (extra_labels or []) if x]
    deadline = time.time() + timeout
    while time.time() < deadline:
        xml = dump_ui(adb_path, device)
        nodes = _parse_nodes(xml)

        def _tap(node):
            _run(adb_path, device, "shell", "input", "tap", str(node["cx"]), str(node["cy"]))

        # pass 0: caller-supplied labels (account picker emails) — exact, clickable preferred
        for want in extra:
            hits = [n for n in nodes if n["text"] == want or n["desc"] == want]
            if hits:
                target = next((n for n in hits if n["clickable"]), hits[0])
                _tap(target)
                return target["text"] or target["desc"]
        # pass 1: exact label matches — clickable node wins, so a heading that happens
        # to carry the same text ("Coba lagi") can never steal the tap from the button
        for want in CONFIRM_EXACT:
            hits = [n for n in nodes if (n["text"] or n["desc"]).strip().lower() == want]
            if hits:
                target = next((n for n in hits if n["clickable"]), hits[0])
                _tap(target)
                return target["text"] or target["desc"]
        # pass 2: prefix matches — ONLY on clickable nodes, so headings can never match
        for want in CONFIRM_PREFIX:
            for n in nodes:
                if not n["clickable"]:
                    continue
                label = (n["text"] or n["desc"]).strip().lower()
                if label and len(label) <= 40 and label.startswith(want):
                    _tap(n)
                    return n["text"] or n["desc"]
        time.sleep(2.5)
    return None


def decode_qr(image_path: str) -> Optional[str]:
    """Decode the first QR code found in a screenshot. Returns its payload URL or None."""
    import cv2

    img = cv2.imread(image_path)
    if img is None:
        return None
    detector = cv2.QRCodeDetector()
    data, _, _ = detector.detectAndDecode(img)
    if not data:
        # retry on a 2x upscale — helps with small/dense QR renders
        big = cv2.resize(img, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_CUBIC)
        data, _, _ = detector.detectAndDecode(big)
    return data or None
