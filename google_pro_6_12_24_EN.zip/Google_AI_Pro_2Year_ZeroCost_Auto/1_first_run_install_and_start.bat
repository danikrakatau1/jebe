@echo off
chcp 65001 >nul
title Google AI Pro (5 TB) 2-Year Zero-Cost Auto Console - First Run (Install Dependencies)
cd /d "%~dp0"
echo ======================================================================
echo   Checking and installing Python dependencies (fastapi, uvicorn, playwright)...
echo ======================================================================
if exist ".venv\Scripts\python.exe" (
  set "PY=.venv\Scripts\python.exe"
) else (
  set "PY=python"
)
%PY% -m pip install -r requirements.txt
echo.
echo ======================================================================
echo   Starting the web console (http://127.0.0.1:8765) ...
echo ======================================================================
start "" "http://127.0.0.1:8765"
%PY% app.py
pause
