@echo off
chcp 65001 >nul
title Google AI Pro (5 TB) 2-Year Zero-Cost Auto Console
cd /d "%~dp0"
echo ======================================================================
echo   Starting Google AI Pro (5 TB) 2-Year Zero-Cost Auto Console...
echo   Console URL: http://127.0.0.1:8765
echo ======================================================================
if exist ".venv\Scripts\python.exe" (
  set "PY=.venv\Scripts\python.exe"
) else (
  set "PY=python"
)
start "" "http://127.0.0.1:8765"
%PY% app.py
pause
