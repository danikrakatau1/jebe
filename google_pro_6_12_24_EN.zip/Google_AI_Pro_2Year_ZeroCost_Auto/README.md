========================================================================
  Google AI Pro (5 TB) 2-Year Zero-Cost (US$0.00 -> 24 months) Auto Console
========================================================================

[1. Requirements]
1. Windows 10 / 11
2. Google Chrome installed (default path is fine)
3. Python 3.10 or newer (check "Add Python to PATH" during install)
4. Network: a US-region proxy on this machine, or fill in a proxy
   template in the left panel of the console

[2. Quick Start]
1. First run: double-click [1_first_run_install_and_start.bat]
2. Daily use: double-click [2_start_console.bat]
3. The console opens automatically at: http://127.0.0.1:8765

[3. Card Setup & Running Accounts]
1. Payment card (required):
   - In the left [Global Config & Inline Tax-Free Card Binding] panel,
     enter your own Visa or Mastercard foreign-currency card:
     * Card number (16 digits)
     * Expiry (month / year, e.g. 08 / 29)
     * Security code (3-digit CVC)
     * Cardholder name (as printed on the card)
     * The tax-free ZIP is pre-filled with 97201 (Oregon, US tax-free
       state) - no change needed
   - Click [Save Config].
   - Note: the script has a strict zero-spend guard - it only clicks
     Subscribe when the checkout modal confirms US$0.00. Zero charges
     throughout.

2. Bulk-import Google accounts:
   - Paste accounts in the right [Bulk Account Import] box (one per
     line). Any of these formats work:
     * email----password----recovery-email
     * email----password----recovery-email----2FA-secret
     * email----password----2FA-secret
   - Click [Import Accounts].

3. Run fully automatically:
   - Click [Run] next to a single account, or [Run All Pending
     Accounts] at the top.
   - The script automatically performs:
     Step 1: Log into Google and pass recovery-email / 2FA verification
     Step 2: Inline tax-free card binding + first-layer 12-month free
             pack (US$0.00)
     Step 3: Stack the second-layer 6-month free pack (US$0.00 -> 18
             months)
     Step 4: Stack the third-layer 6-month free pack (US$0.00 -> 24
             months cap)
     Step 5: Go to Google Play, cancel auto-renewal, lock the 2-year
             benefit and capture a verification screenshot


# Card shop: https://faka.cdkey.si
# Blog: https://blog.caowo.de
# Telegram: @Hello_Florence
